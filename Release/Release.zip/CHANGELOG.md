## 1.5.0
- Remote op support

## 1.4.8
- More Dante support

## 1.4.7

- Fixed FOV slider (sorry for delay! it works now)
- Moved some config options
- Added config options to disable the speed lines when sprinting
- Improved load times
- Added Dante support

## 1.4.6

- Removed FOV slider lol

## 1.4.5

- Added FOV slider

## 1.4.3

- IdleSnipe

## 1.4.2

- Fix delay ticks not resetting on non-agile skills 
- New cfg option to distinguish the two
- Should make animations a bit smoother now

## 1.4.1

- Remove accidental Risk Of Options hard compat

## 1.4.0

- Added configurable FOV changes
- Default setting is to force enable the sprint FOV for the nice 1.3x FOV boost
- Config includes option to keep the original 60 FOV
- Disable both config options to return to vanilla behavior.

## 1.3.6

- toolbot dual wield default
- anim delay works better now
- multi fans eatin good

## 1.3.5

- I'm angry that I have to make EntityState.Idle whitelisted

## 1.3.4

- Fixed body name printing to be accurate

## 1.3.3

- Removed some extra debug stuff
- Made catalog lookups work a lil better

## 1.3.2

- Update readme

## 1.3.1

- Update changelog

## 1.3.0

- Changes like everything. look around at the new settings.
- Disable bodies
- Disable entity states
- disable entity states for a fixed duration
- disable entity states for a duration found in a field within the state
- uses IL hooks now
- has a debug setting to help finding names of things

## 1.2.1

- its rewind time

## 1.2.0

- Fixed compat for BepinExPack's framerate fixes
- Bump to 1.2 cuz i got lost in the sauce
- Added Paladin Cruel Sun to sprint disabled custom list, along with updated instructions on how to use it.
- Cached body and entity state machines for performance
- Reworked update cycle to not be the worst thing ever written

## 1.1.1

- Fixed compat for BepinExPack's framerate fixes
 
## 1.1.0

- Added compat for BepinExPack's framerate fixes

## 1.0.9

- Acrid M1/M2 fix

- Config option for omnisprint, default as false.

## 1.0.8

- False Son Laser fix

## 1.0.7

- Actually implemented the custom state list

## 1.0.6

- Fixed Mul-T powermode (ugh)
- Some config updates for manually adding an sprint blocking entity state name
- Sprinting crosshair disabler actually works (default returned to true. it IS useless huh...)

## 1.0.5

- Fixed railgunner scope and void fiend laser getting instantly cancelled

## 1.0.4

- Fixed Omnisprint

## 1.0.3

- Default value of "Disable Sprinting Crosshair" changed to false. Its not useless :'(

## 1.0.2

- Fixed log spam

## 1.0.0

- First release